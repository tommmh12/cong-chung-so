---
name: Lexicon Protocol
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#45464d'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839b'
  inverse-primary: '#bec6e0'
  secondary: '#505f76'
  on-secondary: '#ffffff'
  secondary-container: '#d0e1fb'
  on-secondary-container: '#54647a'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#002113'
  on-tertiary-container: '#009668'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#d3e4fe'
  secondary-fixed-dim: '#b7c8e1'
  on-secondary-fixed: '#0b1c30'
  on-secondary-fixed-variant: '#38485d'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  mono-label:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: '0'
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 4px
  xs: 8px
  sm: 16px
  md: 24px
  lg: 32px
  xl: 48px
  gutter: 24px
  margin: 32px
  max-content-width: 1440px
---

## Brand & Style
The design system is engineered for high-stakes legal environments where precision, authority, and trust are paramount. The brand personality is **Institutional**, **Reliable**, and **Modern**. It moves away from traditional "dusty" legal aesthetics toward a "Legal Tech" identity that feels technically superior yet fundamentally grounded in law.

The design style follows a **Modern Corporate** approach. It utilizes a rigorous systematic grid, high-contrast typography, and a "Document-First" philosophy. Surfaces are clean and expansive, evoking the clarity of a well-drafted legal instrument. The emotional response should be one of absolute confidence and reduced cognitive load for the notary officer.

## Colors
The palette is anchored by **Deep Navy (#0F172A)**, representing the weight of legal authority. This is used for primary actions, navigation backgrounds, and high-level headings to maintain a strong visual hierarchy.

**Slate Grays (#64748B)** act as the functional workhorse of the system, used for secondary text, icons, and borders to ensure the interface remains calm and unobtrusive. 

**Emerald (#10B981)** is reserved strictly for affirmative states: "Signed," "Verified," or "Success." The background is a crisp **White** or **Slate-50 (#F8FAFC)** to ensure the interface feels airy and modern rather than dense and bureaucratic.

## Typography
**Inter** is the sole typeface for this design system to ensure maximum legibility and a systematic, utilitarian feel. 

- **Headlines:** Use Bold and Semi-Bold weights with slight negative letter-spacing for a modern, compact "editorial" look.
- **Body:** Standardized at 14px and 16px to handle dense information without sacrificing readability.
- **Labels:** Small caps or uppercase labels are used for metadata and status badges to provide clear distinction from body content.
- **Mobile:** Scale `display` down to 28px and `headline-lg` to 22px to maintain hierarchy on narrow viewports.

## Layout & Spacing
The layout follows a **Fixed-Fluid Hybrid Grid**. Content is housed in a centered container with a maximum width of 1440px to prevent excessive line lengths on ultra-wide monitors. 

A 12-column grid is used for desktop layouts, transitioning to a single column for mobile. Spacing follows a strict 4px/8px baseline rhythm. 
- **Generous Padding:** Card containers and document previews should use `lg` (32px) padding to evoke the feeling of physical margins on paper.
- **Density:** Table rows use a tighter `xs` (8px) vertical padding to ensure high data density for record-keeping.

## Elevation & Depth
This design system uses **Low-Contrast Outlines** and **Tonal Layers** rather than dramatic shadows. Depth is communicated through subtle shifts in background color (e.g., a Slate-50 background for the page and White for cards).

- **Level 0 (Flat):** Primary background surfaces.
- **Level 1 (Surface):** White cards with a 1px border in Slate-200 (#E2E8F0).
- **Level 2 (Overlay):** Used for dropdowns and modals. These use a very soft, diffused shadow (0px 4px 20px rgba(15, 23, 42, 0.08)) to distinguish them from the base layout.

## Shapes
Shapes are **Soft** but disciplined. We avoid fully sharp corners to prevent the UI from feeling aggressive, but we strictly avoid "bubbly" or pill-shaped elements that undermine the professional legal tone. 

The standard radius is **4px (0.25rem)** for small components like inputs and buttons. Large containers like cards or document previews may use **8px (0.5rem)** for a slightly more modern feel, but never exceed this threshold.

## Components
- **Buttons:** Primary buttons use Deep Navy backgrounds with White text. Secondary buttons are outlined in Slate-300. Hover states involve a subtle darken effect, never a color shift.
- **Data Tables:** These are the heart of the system. Use "Zebra-striping" only on hover. Headers must be in uppercase `label-md` style with a subtle Slate-100 bottom border.
- **Status Badges:** Use a "Light-on-Dark" or "Tinted" approach. A "Pending" status uses a light Slate background with Deep Navy text; "Verified" uses a light Emerald tint with Dark Emerald text.
- **Inputs:** Fields are rectangular with a 1px border. On focus, the border shifts to Deep Navy with a 2px "ring" of soft Slate-200.
- **Document Previews:** Containers that hold PDFs or legal text should have a subtle 1px border and a slight inner shadow to simulate the depth of paper within a digital frame.
- **Chips/Tags:** Used for "Case Types" or "Jurisdiction," these should be rectangular with slightly rounded corners and neutral color fills.